package pages;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;




public class CheckoutTest {
	
	Object wait;
	String existingUserEmail = "mflsqe@naic.org";
    String existingUserPassword = "mflsqe1234";
    static WebElement email;
    static WebElement login;
    

	public CheckoutTest(WebDriver driver)
	{	
		WebDriverWait wait = new WebDriverWait(driver, 10, 50);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("login"))).click();
     driver.findElement(By.id("email")).sendKeys(existingUserEmail);
     driver.findElement(By.id("passwd")).sendKeys(existingUserPassword);
     driver.findElement(By.id("SubmitLogin")).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Women"))).click();
     driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[1]/div/a[1]/img")).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("Submit"))).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Proceed to checkout"))).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Proceed to checkout"))).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("processAddress"))).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("uniform-cgv"))).click();
     driver.findElement(By.name("processCarrier")).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bankwire"))).click();
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='cart_navigation']/button"))).click();
     WebElement heading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h1")));
     assertEquals("ORDER CONFIRMATION", heading.getText());
     assertTrue(driver.findElement(By.xpath("//li[@class='step_done step_done_last four']")).isDisplayed());
     assertTrue(driver.findElement(By.xpath("//li[@id='step_end' and @class='step_current last']")).isDisplayed());
     assertTrue(driver.findElement(By.xpath("//*[@class='cheque-indent']/strong")).getText().contains("Your order on My Store is complete."));
     assertTrue(driver.getCurrentUrl().contains("controller=order-confirmation"));
	}

}
