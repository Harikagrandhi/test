package NAIC;

import org.testng.annotations.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.CheckoutTest;
import pages.LogInTest;
import pages.SignInTest;


public class N_Test {
	
	static FirefoxDriver driver;
	static WebDriverWait wait;
	LogInTest login;
	CheckoutTest checkout;
	SignInTest signin;
	
	@Test(priority=0)
	
	public void Verify_test()
	{
		login=new LogInTest(driver);
		signin= new SignInTest(driver);
		checkout=new CheckoutTest(driver);
	}
	
	  
  @BeforeMethod
  public void beforeMethod()
  {
	  
		    driver = new FirefoxDriver();
	        wait = new WebDriverWait(driver, 10, 50);
	       	driver.get("http://automationpractice.com/index.php");
  }
  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}


